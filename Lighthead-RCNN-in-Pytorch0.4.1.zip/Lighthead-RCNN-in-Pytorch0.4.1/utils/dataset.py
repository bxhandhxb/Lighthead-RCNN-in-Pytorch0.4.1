from pycocotools.coco import COCO
from torch.utils.data import Dataset
from collections import namedtuple
import torch
import numpy as np
import random
from PIL import Image
from utils.bbox_tools import adjust_bbox, horizontal_flip_boxes, xywh_2_x1y1x2y2, y1x1y2x2_2_x1y1x2y2
from chainercv.datasets import VOCBboxDataset
from chainercv.chainer_experimental.datasets.sliceable import ConcatenatedDataset
from chainercv.transforms.image.resize import resize
import pdb

class coco_dataset(Dataset):
    def __init__(self, conf, mode = 'train'):
        assert mode == 'train' or mode == 'val', 'mode shoulde be train or val'    
        if mode == 'train':
            self.training = True
            self.orig_dataset = VOCBboxDataset(data_dir=str(conf.coco_path), split='train')
            print('train dataset imported')
        else:
            self.training = False
            self.orig_dataset = VOCBboxDataset(data_dir=str(conf.coco_path), 
                                                split='val',
						use_difficult=True,
						return_difficult=True)
            print('minival dataset imported')
        self.pair = namedtuple('pair', ['img', 'bboxes', 'labels', 'scale'])
        self.maps = conf.maps
        self.min_sizes = conf.min_sizes
        self.max_size = conf.max_size
        self.mean = conf.mean
#         self.std = conf.std
    
    def __len__(self):
        return len(self.orig_dataset)
    
    def __getitem__(self, index):
        if self.training:
            img, bboxes, labels = self.orig_dataset[index]
        else:
            img, bboxes, labels, _ = self.orig_dataset[index]
        img, scale = self.prepare_img(img, not self.training)
        if len(bboxes) == 0:
#             print('index {} dosent have objects'.format(index))
            return self.pair(img, [], [], scale)
        bboxes = y1x1y2x2_2_x1y1x2y2(bboxes)
        bboxes = adjust_bbox(scale, bboxes)
        if self.training:
            if random.random() > 0.5:
                img[:] = img[:, :, ::-1]
                bboxes = horizontal_flip_boxes(bboxes, img.shape[-1])
#         img = torch.tensor(img).unsqueeze(0)
        img_size = [img.shape[1], img.shape[2]] # H,W
        bboxes[:, slice(0, 4, 2)] = np.clip(bboxes[:, slice(0, 4, 2)], 0, img_size[1])
        # roi[:, [0,2]] 跟 roi[:, slice(0, 4, 2)] 不是一样嘛
        # 求出[y1,y2]之后用np.clip去掉bboxes伸出到图像尺寸之外的部分
        # 注意这里的img_size是原始图像经过放缩之后，输入到神经网络的size
        bboxes[:, slice(1, 4, 2)] = np.clip(bboxes[:, slice(1, 4, 2)], 0, img_size[0])
        return self.pair(img, bboxes, labels, scale)
    
    def prepare_img(self, img, infer = False):
        """Preprocess an image for feature extraction.

        The length of the shorter edge is scaled to :obj:`conf.min_size`.
        After the scaling, if the length of the longer edge is longer than
        :obj:`conf.max_size`, the image is scaled to fit the longer edge
        to :obj:`conf.max_size`.

        Args:
            img (np.array): RGB img [3,H,W] 

        Returns:
            A preprocessed image.
            resize scale
        """
        W, H = img.shape[2], img.shape[1]
        if infer:
            min_size = self.min_sizes[-1]
        else:
            min_size = random.choice(self.min_sizes)
        scale = min_size / min(H, W)
        if scale * max(H, W) > self.max_size:
            scale = self.max_size / max(H, W)
        img = resize(img, (int(H * scale), int(W * scale)))
        img = (img - self.mean).astype(np.float32, copy=False)
        return img, scale

def prepare_img(conf, img, resolution = -1):
    """Preprocess an image for feature extraction.

    The length of the shorter edge is scaled to :obj:`conf.min_size`.
    After the scaling, if the length of the longer edge is longer than
    :obj:`conf.max_size`, the image is scaled to fit the longer edge
    to :obj:`conf.max_size`.

    Args:
        img (np.array): RGB img [3,H,W] 

    Returns:
        A preprocessed image.
        resize scale
    """
    W, H = img.shape[2], img.shape[1]
    min_size = conf.min_sizes[resolution]
    scale = min_size / min(H, W)
    if scale * max(H, W) > conf.max_size:
        scale = conf.max_size / max(H, W)
    print(conf.max_size)
    print(img.shape)
    print(int(H * scale), int(W * scale))
    img = resize(img, (int(H * scale), int(W * scale)))
    img = (img - conf.mean).astype(np.float32, copy=False)
    return img, scale    
