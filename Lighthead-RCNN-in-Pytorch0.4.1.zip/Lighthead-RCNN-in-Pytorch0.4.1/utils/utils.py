from torch.nn import Conv2d, Linear
from datetime import datetime

try:
    import pycocotools.coco
    import pycocotools.cocoeval
    _available = True
except ImportError:
    _available = False

import chainer
from chainer import iterators
from chainercv.datasets import voc_bbox_label_names
from chainercv.datasets import VOCBboxDataset
from chainercv.evaluations import eval_detection_voc
from chainercv.utils import apply_to_iterator
from chainercv.utils import ProgressHook

def eva_coco(dataset, func, limit = 1000, preset = 'evaluate'):
    total = limit if limit else len(dataset)
    orig_ids = dataset.ids.copy()
    dataset.ids = dataset.ids[:total]
    iterator = iterators.SerialIterator(dataset, 1, repeat=False, shuffle=False)
    in_values, out_values, rest_values = apply_to_iterator(func, 
                                                           iterator, 
                                                           hook=ProgressHook(len(dataset)))
    pred_bboxes, pred_labels, pred_scores = out_values
    gt_bboxes, gt_labels, gt_difficults= rest_values
#    print(pred_labels)
#    print("pred_bboxes : {}".format(len(pred_bboxes)))
#    print("pred_labels : {}".format(len(pred_labels)))
#    print("gt_bboxes : {}".format(len(gt_bboxes)))
#    print("gt_labels : {}".format(len(gt_labels)))
    result = eval_detection_voc(pred_bboxes, pred_labels, pred_scores, gt_bboxes, gt_labels, gt_difficults)
    print("")
    results = []
    for key in result.keys():
        print('{:s}: {}'.format(key, result[key]))
        # results.append(result[key])
    dataset.ids = orig_ids
    return result

def normal_init(m, mean, stddev):
    if type(m) == Linear or type(m) == Conv2d:
        m.weight.data.normal_(mean, stddev)
        m.bias.data.zero_()
        
def get_time():
    return (str(datetime.now())[:-10]).replace(' ','-').replace(':','-')
