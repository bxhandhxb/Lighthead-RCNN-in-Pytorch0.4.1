python tests/test.py
python tests/test2.py
python tests/crop_and_resize_example.py
